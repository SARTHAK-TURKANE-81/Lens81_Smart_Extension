// content.js
// Runs on Google Scholar search-result pages. Finds each result, shows an
// instant title-based guess, asks the background worker to confirm it
// against the abstract, and swaps in the confirmed badge when it arrives.

const PROCESSED_ATTR = 'data-classifier-done';
const REVIEW_KEYWORDS = /\b(survey|review|systematic review|meta-analysis|overview of)\b/i;

function quickGuessType(title) {
  return REVIEW_KEYWORDS.test(title) ? 'Review' : 'Research';
}

function makeDot() {
  const dot = document.createElement('span');
  dot.className = 'dot';
  return dot;
}

// Shown the instant a title is read — before any network call resolves —
// so the page never sits there with nothing but a spinner.
function makePendingBadge(title) {
  const badge = document.createElement('span');
  const isReview = quickGuessType(title) === 'Review';
  badge.className = `paper-type pending low-confidence ${isReview ? 'review' : 'research'}`;
  badge.appendChild(makeDot());
  badge.appendChild(document.createTextNode(`${isReview ? 'Review' : 'Research'}?`));
  badge.title = 'Quick guess from the title — confirming against the abstract…';
  return badge;
}

function makeResultBadge(result) {
  const badge = document.createElement('span');
  const isReview = result.type === 'Review';
  badge.className = `paper-type ${isReview ? 'review' : 'research'}`;
  const label = isReview ? 'Review' : 'Research';
  const confidence = Number.isFinite(result.confidence) ? ` · ${result.confidence}%` : '';
  badge.appendChild(makeDot());
  badge.appendChild(document.createTextNode(`${label}${confidence}`));

  if (result.source === 'llm-title-only') {
    badge.title = 'No abstract was found for this paper — the AI classified it from the title alone.';
    badge.classList.add('low-confidence');
  } else if (result.source === 'title-heuristic') {
    badge.title = 'No abstract was found and no AI is configured — this is a keyword-only guess.';
    badge.classList.add('low-confidence');
  }
  return badge;
}

function makeUnavailableBadge() {
  const badge = document.createElement('span');
  badge.className = 'paper-type error';
  badge.appendChild(makeDot());
  badge.appendChild(document.createTextNode('unavailable'));
  return badge;
}

function extractTitle(h3) {
  // Google Scholar sometimes prefixes titles with tags like [PDF] or [BOOK].
  return h3.innerText.replace(/^\[[^\]]+\]\s*/, '').trim();
}

function processResult(resultEl) {
  if (resultEl.getAttribute(PROCESSED_ATTR)) return;

  const h3 = resultEl.querySelector('h3.gs_rt, h3');
  if (!h3) return;

  const title = extractTitle(h3);
  if (!title) return;

  // Mark as handled only once we know we have a usable title, so a
  // temporarily-empty node doesn't get skipped permanently.
  resultEl.setAttribute(PROCESSED_ATTR, '1');

  const pendingBadge = makePendingBadge(title);
  h3.appendChild(pendingBadge);

  chrome.runtime.sendMessage({ type: 'CLASSIFY_PAPER', title }, (response) => {
    if (chrome.runtime.lastError || !response) {
      pendingBadge.replaceWith(makeUnavailableBadge());
      return;
    }
    if (response.error) {
      pendingBadge.replaceWith(makeUnavailableBadge());
      return;
    }
    pendingBadge.replaceWith(makeResultBadge(response));
  });
}

function scan() {
  document.querySelectorAll('.gs_ri').forEach(processResult);
}

// Google Scholar's DOM can settle a little after the initial load, and
// pagination re-renders results without a full navigation in some cases,
// so watch for changes instead of scanning only once.
let scanTimer = null;
function scheduleScan() {
  if (scanTimer) return;
  scanTimer = setTimeout(() => {
    scanTimer = null;
    scan();
  }, 150);
}

scheduleScan();
new MutationObserver(scheduleScan).observe(document.body, { childList: true, subtree: true });
