// options.js
// Renders up to 5 "API key + model" rows, backed by chrome.storage.local
// under a single `openrouterConfigs` array: [{ key, model, onlyIfNeeded }, ...].
// A row checked "only use if needed" is held back by the background worker
// and only called if none of the regular rows produced a usable result —
// useful for a backup/cheaper key you don't want spending a request on
// every single paper.
//
// Backward compatibility: installs from before multi-model support stored a
// single pair under `openrouterKey` / `openrouterModel`. On load, if no
// `openrouterConfigs` exists yet, that legacy pair is migrated into row 1
// so existing users keep working without re-entering anything.

const MAX_ROWS = 5;

const rowsContainer = document.getElementById('model-rows');
const saveBtn = document.getElementById('save');
const status = document.getElementById('status');
const banner = document.getElementById('banner');
const clearStatus = document.getElementById('clear-status');

let statusGeneration = 0;

function showStatus(kind, message) {
  // kind: 'ok' | 'err' | 'neutral'
  statusGeneration++;
  status.textContent = message;
  status.className = `pill-status ${kind}`;
  status.style.display = 'inline-flex';
}

function hideStatusLater(delay = 2200) {
  // Capture the generation so a stale timer (e.g. from Save) can't hide a
  // newer message shown afterward (e.g. from a row's Test button).
  const generation = statusGeneration;
  setTimeout(() => {
    if (generation === statusGeneration) {
      status.style.display = 'none';
    }
  }, delay);
}

// --- Row rendering -----------------------------------------------------

function buildRow(index) {
  const wrap = document.createElement('div');
  wrap.className = 'model-row';
  wrap.dataset.index = String(index);

  const isFirst = index === 0;
  wrap.innerHTML = `
    <div class="model-row-header">
      <span class="model-row-title">Model ${index + 1}</span>
      <span class="model-row-tag">${isFirst ? 'Required' : 'Optional'}</span>
    </div>
    <div class="field">
      <label>OpenRouter API key</label>
      <div class="input-row">
        <input type="password" class="key-input row-key" placeholder="sk-or-v1-…" autocomplete="off" />
        <button type="button" class="toggle-visibility row-toggle-key">Show</button>
      </div>
    </div>
    <div class="field">
      <label>Model slug</label>
      <input type="text" class="row-model" placeholder="~anthropic/claude-haiku-latest" autocomplete="off" />
    </div>
    <label class="row-fallback">
      <input type="checkbox" class="row-only-if-needed" />
      <span>Only use this key if the others fail <em>(saves API cost — held back unless it's needed)</em></span>
    </label>
    <div class="row-actions">
      <button type="button" class="row-test">Test</button>
      <span class="row-status pill-status neutral" style="display:none;"></span>
    </div>
  `;
  return wrap;
}

function renderRows() {
  rowsContainer.innerHTML = '';
  for (let i = 0; i < MAX_ROWS; i++) {
    rowsContainer.appendChild(buildRow(i));
  }
  wireRowEvents();
}

function wireRowEvents() {
  rowsContainer.querySelectorAll('.model-row').forEach((row) => {
    const keyInput = row.querySelector('.row-key');
    const toggleBtn = row.querySelector('.row-toggle-key');
    const testBtn = row.querySelector('.row-test');
    const rowStatus = row.querySelector('.row-status');
    const modelInput = row.querySelector('.row-model');

    toggleBtn.addEventListener('click', () => {
      const hidden = keyInput.type === 'password';
      keyInput.type = hidden ? 'text' : 'password';
      toggleBtn.textContent = hidden ? 'Hide' : 'Show';
    });

    testBtn.addEventListener('click', () => {
      const key = keyInput.value.trim();
      const model = modelInput.value.trim();

      if (!key || !model) {
        setRowStatus(rowStatus, 'err', 'Add a key and model first.');
        return;
      }

      setRowStatus(rowStatus, 'neutral', 'Testing…');
      testBtn.disabled = true;

      chrome.runtime.sendMessage({ type: 'TEST_KEY', key, model }, (response) => {
        testBtn.disabled = false;
        if (chrome.runtime.lastError || !response) {
          setRowStatus(rowStatus, 'err', 'Could not reach the background worker.');
          return;
        }
        setRowStatus(rowStatus, response.ok ? 'ok' : 'err', response.message);
      });
    });
  });
}

function setRowStatus(el, kind, message) {
  el.textContent = message;
  el.className = `row-status pill-status ${kind}`;
  el.style.display = 'inline-flex';
}

function getRows() {
  return Array.from(rowsContainer.querySelectorAll('.model-row'));
}

function readRowValues() {
  return getRows().map((row) => ({
    key: row.querySelector('.row-key').value.trim(),
    model: row.querySelector('.row-model').value.trim(),
    onlyIfNeeded: row.querySelector('.row-only-if-needed').checked,
  }));
}

function writeRowValues(configs) {
  getRows().forEach((row, i) => {
    const entry = configs[i] || { key: '', model: '', onlyIfNeeded: false };
    row.querySelector('.row-key').value = entry.key || '';
    row.querySelector('.row-model').value = entry.model || '';
    row.querySelector('.row-only-if-needed').checked = Boolean(entry.onlyIfNeeded);
  });
}

// --- Load / migrate / save ------------------------------------------------

async function refreshBanner(configs) {
  const anyConfigured = configs.some((c) => c.key && c.model);
  banner.classList.toggle('show', !anyConfigured);
}

async function load() {
  renderRows();

  const stored = await chrome.storage.local.get([
    'openrouterConfigs',
    'openrouterKey',
    'openrouterModel',
  ]);

  let configs = Array.isArray(stored.openrouterConfigs) ? stored.openrouterConfigs : null;

  if (!configs) {
    // Legacy single key/model install — migrate into row 1 on the fly.
    configs = [];
    if (stored.openrouterKey && stored.openrouterModel) {
      configs.push({ key: stored.openrouterKey, model: stored.openrouterModel });
    }
  }

  writeRowValues(configs);
  await refreshBanner(configs);
}

saveBtn.addEventListener('click', async () => {
  const configs = readRowValues();
  await chrome.storage.local.set({ openrouterConfigs: configs });
  // Once this page has been saved once, openrouterConfigs is the source of
  // truth going forward, so the old single-pair fields can be cleared.
  // (The background worker still reads them as a fallback for any install
  // that hasn't opened this settings page since the update.)
  await chrome.storage.local.remove(['openrouterKey', 'openrouterModel']);

  showStatus('ok', 'Saved.');
  hideStatusLater();
  await refreshBanner(configs);
});

document.getElementById('clear-cache').addEventListener('click', async () => {
  const all = await chrome.storage.local.get(null);
  const cacheKeys = Object.keys(all).filter((k) => k.startsWith('classify:'));
  await chrome.storage.local.remove(cacheKeys);
  clearStatus.textContent = `Cleared ${cacheKeys.length} cached result(s).`;
  setTimeout(() => (clearStatus.textContent = ''), 2500);
});

document.getElementById('back').addEventListener('click', () => {
  // Options pages usually open in their own tab with nothing before them in
  // history, so fall back to closing the tab when there's nowhere to go back to.
  if (window.history.length > 1) {
    window.history.back();
  } else {
    window.close();
  }
});

load();
