# Lens⁸¹

Labels each Google Scholar result as **Research** or **Review** by looking up
its abstract (Semantic Scholar, falling back to OpenAlex) and classifying it
with an ensemble of up to 5 LLMs you access through your own OpenRouter keys.

## Load it in Chrome

1. Go to `chrome://extensions`.
2. Turn on **Developer mode** (top right).
3. Click **Load unpacked** and select this folder.
4. Click the extension icon → **Open settings**.

## Configure OpenRouter

The settings page has 5 "Model" rows — Model 1 is required, Models 2–5 are
optional. Fill in as many as you want (1 is enough for the extension to
work; more rows means the ensemble averages more models' predictions).

For each row you use:

1. Create a key at [openrouter.ai/keys](https://openrouter.ai/keys) and paste
   it in. Keys are stored only in your browser (`chrome.storage.local`) and
   are sent only to `openrouter.ai` — never bundled into the extension or
   sent anywhere else.
2. Pick a model slug from [openrouter.ai/models](https://openrouter.ai/models)
   and paste it in exactly (e.g. `anthropic/claude-haiku-4.5`,
   `openai/gpt-4o-mini`, or any other chat model on the site). The catalog and
   pricing change over time, so check the site rather than trusting a
   hardcoded default — the extension intentionally ships with these fields
   blank. Each row can use a different model.
3. Click that row's **Test** button — this sends one tiny real request
   through OpenRouter so a bad key or mistyped model slug shows up
   immediately instead of failing silently later on a Scholar page.
4. Optionally, check **"Only use this key if the others fail"** on a row.
   That key is held back and only called when every regular row failed or
   timed out on a given paper — handy for a backup or free-tier key you
   don't want spending a request on every single paper, only on the ones
   your main model(s) couldn't handle.

When you're done, click **Save** once at the bottom to store all the rows.

## Use it

Open a search results page on `scholar.google.com`. Each result gets a small
chip — cyan for Research, amber for Review — next to the title once its
abstract has been classified. The toolbar icon shows a running count for the
current tab, and clicking it opens a popup with a Research/Review breakdown.
Results are cached locally for 30 days per title, so revisiting a search
won't re-spend API calls.

If no key/model is set, or no abstract can be found for a paper, the
extension falls back to a title-keyword heuristic (looking for words like
"survey," "review," "systematic review," "meta-analysis") and marks the badge
as lower-confidence — hover it to see the note.

## How it works

```
Google Scholar page
   │  content.js scans .gs_ri result blocks, extracts each title
   ▼
background.js (service worker)
   │  checks chrome.storage.local cache
   │  fetches abstract: Semantic Scholar → OpenAlex fallback
   │  (OpenAlex returns an inverted-index, which is reconstructed to text)
   │  verifies the returned title actually matches before trusting it
   ▼
The exact same prompt is sent to every configured OpenRouter (key, model)
pair in parallel (Promise.allSettled) — 1 to 5 models
   │  each is prompted to return
   │  {"prediction": "...", "research_probability": 0-1, "review_probability": 0-1}
   │  as JSON
   ▼
Ensemble: research_probability and review_probability are averaged across
every model that answered successfully; whichever average is higher wins
   ▼
Badge injected next to the title on the page, result cached
```

## Performance & reliability

Three specific fixes worth knowing about, since they weren't there originally:

- **Instant guess, then confirmation.** Each result gets a dashed, "…?"
  badge immediately from a title keyword check (0ms), then it's swapped for
  the confirmed abstract-based badge when that arrives. You're never staring
  at a blank spinner.
- **Every network call has a timeout** (6s for abstract lookups, 12s for the
  LLM call). Before this, a single stalled request could leave a badge stuck
  forever with no fallback — now it always resolves to something.
- **Per-tab counts survive the service worker being unloaded.** Chrome can
  suspend an extension's background worker whenever it's been idle for a bit
  — including simply because you switched away from the tab. The running
  Research/Review counts are now kept in `chrome.storage.session` instead of
  a plain variable, so they don't reset just because the tab wasn't focused.
  This needs Chrome 102+; anything from the last few years is fine.
- Semantic Scholar and OpenAlex are now queried **in parallel** instead of
  one-after-the-other, which roughly halves the wait on papers Semantic
  Scholar doesn't have (a common case).

## Known limitations

- **Selectors are fragile.** Google Scholar's markup (`.gs_ri`, `h3`) can
  change; if badges stop appearing, that's the first place to check.
- **Chrome only for now** (Manifest V3, `service_worker` background). A
  Firefox build needs a separate manifest since Firefox's MV3 background
  model differs — happy to add this next if you want it.
- **Not every paper is indexed** in Semantic Scholar or OpenAlex, and some
  publishers withhold abstracts from these APIs, so the heuristic fallback
  will trigger for a portion of results.
- **Title matching is approximate.** A crude similarity check filters out
  obviously wrong matches, but very generic titles could still occasionally
  pull the wrong paper's abstract.

## Files

| File | Role |
|---|---|
| `manifest.json` | Extension config (MV3) |
| `content.js` | Scans the Scholar page, injects badges |
| `background.js` | Abstract lookup, caching, OpenRouter calls, ensemble |
| `options.html` / `options.js` | Where you set up to 5 API key + model pairs |
| `popup.html` / `popup.js` | Toolbar popup, shows setup status |
| `styles.css` | Badge appearance |
