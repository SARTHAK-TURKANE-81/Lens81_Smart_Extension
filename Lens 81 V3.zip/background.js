// background.js (MV3 service worker)
// Handles messages from content.js: looks up an abstract, classifies it,
// caches the result, and returns it.
//
// Two reliability rules this file follows, because a service worker can be
// suspended by Chrome at any time (e.g. when its tab isn't focused):
//   1. Every network call has a timeout, so one stalled request can't leave
//      a badge stuck on "checking…" forever.
//   2. Per-tab counters live in chrome.storage.session, not a plain JS
//      variable, so they survive the worker being unloaded and restarted.

const CACHE_TTL_MS = 30 * 24 * 60 * 60 * 1000; // 30 days
const REVIEW_KEYWORDS = /\b(survey|review|systematic review|meta-analysis|overview of)\b/i;

const ABSTRACT_TIMEOUT_MS = 6000;
const LLM_TIMEOUT_MS = 12000;
const TEST_TIMEOUT_MS = 8000;
// Hard ceiling on the whole classifyPaper() pipeline (abstract lookup, then
// the model ensemble). Individual network calls already time out on their
// own, but nothing previously bounded the *combined* worst case — a slow
// abstract lookup stacked with a slow model call could together run long
// enough that Chrome tears down the message channel back to content.js
// before sendResponse() ever fires ("the message port closed before a
// response was received"), leaving that paper's badge stuck pending
// forever. This guarantees classifyPaper() always settles well before that,
// falling back to the keyword heuristic if the real pipeline is too slow.
const OVERALL_CLASSIFY_TIMEOUT_MS = 20000;

chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.status === 'loading') {
    chrome.storage.session.remove(tabStatsKey(tabId)).catch(() => {});
    setBadge(tabId, '', null);
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === 'CLASSIFY_PAPER') {
    classifyPaper(message.title)
      .then(async (result) => {
        if (sender.tab?.id != null) await recordStat(sender.tab.id, result);
        sendResponse(result);
      })
      .catch(() => sendResponse({ error: 'unavailable' }));
    return true; // keep the message channel open for the async sendResponse
  }

  if (message?.type === 'GET_TAB_STATUS') {
    getTabStats(message.tabId).then(sendResponse);
    return true;
  }

  if (message?.type === 'TEST_KEY') {
    testKey(message.key, message.model)
      .then(sendResponse)
      .catch((err) => sendResponse({ ok: false, message: String(err) }));
    return true;
  }

  return false;
});

// --- Per-tab stats, persisted so a worker restart doesn't lose them -------

function tabStatsKey(tabId) {
  return `tabstats:${tabId}`;
}

async function getTabStats(tabId) {
  const stored = await chrome.storage.session.get(tabStatsKey(tabId));
  return stored[tabStatsKey(tabId)] || { research: 0, review: 0, total: 0 };
}

async function recordStat(tabId, result) {
  const stats = await getTabStats(tabId);
  if (result.type === 'Review') stats.review += 1;
  else if (result.type === 'Research') stats.research += 1;
  else return; // classification errored out — don't count it
  stats.total += 1;

  await chrome.storage.session.set({ [tabStatsKey(tabId)]: stats });
  setBadge(tabId, String(stats.total), '#06AED5');
}

// Classification can now take up to ~20s (see OVERALL_CLASSIFY_TIMEOUT_MS),
// which is plenty of time for the person to close the tab before a result
// comes back. chrome.action.setBadgeText/setBadgeBackgroundColor throw
// "No tab with id: <id>" in that case — an entirely expected race, not a
// real failure — so it's swallowed here instead of surfacing as an
// unhandled promise rejection in the service worker's console.
function setBadge(tabId, text, color) {
  chrome.action.setBadgeText({ tabId, text }).catch(() => {});
  if (color) chrome.action.setBadgeBackgroundColor({ tabId, color }).catch(() => {});
}

// --- Networking helper -----------------------------------------------------

async function fetchWithTimeout(url, options = {}, timeoutMs = 6000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...options, signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

// --- Classification pipeline ------------------------------------------------

async function classifyPaper(title) {
  const cacheKey = 'classify:' + normalize(title);
  const cached = await getCache(cacheKey);
  if (cached) return cached;

  const result = await withOverallTimeout(
    classifyUncached(title),
    OVERALL_CLASSIFY_TIMEOUT_MS,
    () => heuristicClassify(title)
  );

  await setCache(cacheKey, result);
  return result;
}

async function classifyUncached(title) {
  const abstract = await fetchAbstract(title);
  // If no abstract was found, still ask the AI — using just the title is
  // meaningfully better than a keyword regex — before falling back further.
  return abstract ? await classifyWithLLM(title, abstract) : await classifyTitleOnly(title);
}

// Races `promise` against a timer. Whichever settles first wins; the loser
// is simply ignored (its own timeouts/AbortControllers still clean it up
// independently). Used so classifyPaper() can never take meaningfully
// longer than `ms`, regardless of how slow the network calls inside it are.
function withOverallTimeout(promise, ms, fallbackFn) {
  return new Promise((resolve) => {
    let settled = false;
    const timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      resolve(fallbackFn());
    }, ms);

    promise.then(
      (value) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        resolve(value);
      },
      () => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        resolve(fallbackFn());
      }
    );
  });
}

async function testKey(key, model) {
  if (!key || !model) return { ok: false, message: 'Add both a key and a model first.' };

  try {
    const res = await fetchWithTimeout(
      'https://openrouter.ai/api/v1/chat/completions',
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${key}`,
        },
        body: JSON.stringify({
          model,
          messages: [{ role: 'user', content: 'Reply with the single word: ok' }],
          max_tokens: 5,
        }),
      },
      TEST_TIMEOUT_MS
    );

    if (res.ok) return { ok: true, message: 'Connected.' };

    const body = await res.json().catch(() => null);
    const detail = body?.error?.message || `HTTP ${res.status}`;
    return { ok: false, message: detail };
  } catch (err) {
    if (err.name === 'AbortError') {
      return { ok: false, message: 'Timed out — check your connection and try again.' };
    }
    return { ok: false, message: 'Network error — check your connection and try again.' };
  }
}

function normalize(text) {
  return text.trim().toLowerCase().replace(/\s+/g, ' ');
}

async function getCache(key) {
  const stored = await chrome.storage.local.get(key);
  const entry = stored[key];
  if (!entry || Date.now() - entry.savedAt > CACHE_TTL_MS) return null;
  // Entries saved by a pre-ensemble-reasoning version of this extension
  // won't have `reason`/`details` — treat them as a miss so the paper gets
  // reclassified once (and re-cached in the new shape) instead of silently
  // showing an empty "why" panel until the 30-day TTL clears it out.
  if (!('reason' in entry.value) || !('details' in entry.value)) return null;
  return entry.value;
}

async function setCache(key, value) {
  await chrome.storage.local.set({ [key]: { value, savedAt: Date.now() } });
}

// --- Abstract lookup ------------------------------------------------------

function titleSimilarity(a, b) {
  a = normalize(a);
  b = normalize(b);
  if (!a || !b) return 0;
  if (a === b) return 1;
  const shorter = a.length < b.length ? a : b;
  const longer = a.length < b.length ? b : a;
  if (longer.includes(shorter)) return shorter.length / longer.length;
  const aTokens = new Set(a.split(' '));
  const bTokens = new Set(b.split(' '));
  const overlap = [...aTokens].filter((t) => bTokens.has(t)).length;
  return overlap / Math.max(aTokens.size, bTokens.size);
}

// Semantic Scholar and OpenAlex are queried in parallel — previously this
// waited for Semantic Scholar to finish (or time out) before ever trying
// OpenAlex, which roughly doubled the wait on any paper Semantic Scholar
// doesn't have. Whichever answers first with a usable abstract wins.
async function fetchAbstract(title) {
  const [ss, oa] = await Promise.allSettled([
    fetchFromSemanticScholar(title),
    fetchFromOpenAlex(title),
  ]);
  if (ss.status === 'fulfilled' && ss.value) return ss.value;
  if (oa.status === 'fulfilled' && oa.value) return oa.value;
  return null;
}

async function fetchFromSemanticScholar(title) {
  const url =
    'https://api.semanticscholar.org/graph/v1/paper/search' +
    `?query=${encodeURIComponent(title)}&fields=title,abstract&limit=1`;
  const res = await fetchWithTimeout(url, {}, ABSTRACT_TIMEOUT_MS);
  if (!res.ok) return null;
  const data = await res.json();
  const paper = data?.data?.[0];
  if (!paper?.abstract) return null;
  if (titleSimilarity(title, paper.title) < 0.6) return null;
  return paper.abstract;
}

async function fetchFromOpenAlex(title) {
  const url = `https://api.openalex.org/works?search=${encodeURIComponent(title)}&per-page=1`;
  const res = await fetchWithTimeout(url, {}, ABSTRACT_TIMEOUT_MS);
  if (!res.ok) return null;
  const data = await res.json();
  const work = data?.results?.[0];
  if (!work) return null;
  if (titleSimilarity(title, work.display_name) < 0.6) return null;
  // OpenAlex stores abstracts as a word -> positions map, not plain text.
  return reconstructAbstract(work.abstract_inverted_index);
}

function reconstructAbstract(invertedIndex) {
  if (!invertedIndex) return null;
  const positions = [];
  for (const [word, indices] of Object.entries(invertedIndex)) {
    for (const idx of indices) positions[idx] = word;
  }
  const text = positions.join(' ').trim();
  return text || null;
}

// --- Classification ---------------------------------------------------

function heuristicClassify(title) {
  const match = title.match(REVIEW_KEYWORDS);
  const isReview = Boolean(match);
  const reason = isReview
    ? `Title contains the review-type keyword "${match[0]}".`
    : 'Title does not contain any review-type keywords (survey, review, meta-analysis, etc.), so it defaults to Research.';
  return {
    type: isReview ? 'Review' : 'Research',
    confidence: 55,
    source: 'title-heuristic',
    reason,
    details: [],
  };
}

async function classifyWithLLM(title, abstract) {
  const parsed = await callOpenRouterClassifier(buildAbstractPrompt(title, abstract));
  return parsed ? { ...parsed, source: 'llm' } : heuristicClassify(title);
}

// Used when no abstract could be found. A title-only guess from an actual
// model is still meaningfully better than a fixed keyword regex, and is
// labeled distinctly in the UI so it isn't confused with an abstract-verified
// result.
async function classifyTitleOnly(title) {
  const parsed = await callOpenRouterClassifier(buildTitleOnlyPrompt(title));
  return parsed ? { ...parsed, source: 'llm-title-only' } : heuristicClassify(title);
}

function buildAbstractPrompt(title, abstract) {
  return `You are an expert at identifying academic paper types.
Classify the paper as exactly one of: "Research Paper" or "Review Paper".

Title: ${title}
Abstract: ${abstract}

Respond with ONLY compact JSON, no other text:
{"prediction":"Research" or "Review","research_probability":0-1,"review_probability":0-1,"reason":"one short sentence explaining why, based on the abstract"}`;
}

function buildTitleOnlyPrompt(title) {
  return `You are an expert at identifying academic paper types.
No abstract is available for this paper. Using only the title and your general knowledge of how research papers versus review papers are typically titled in this field, make your best judgment. Reflect your reduced certainty in the probabilities.

Title: ${title}

Classify as exactly one of: "Research Paper" or "Review Paper".
Respond with ONLY compact JSON, no other text:
{"prediction":"Research" or "Review","research_probability":0-1,"review_probability":0-1,"reason":"one short sentence explaining why, based on the title"}`;
}

// --- Multi-model ensemble ---------------------------------------------------
//
// Up to 5 OpenRouter (key, model) pairs can be configured. The exact same
// prompt is sent to every "always" pair in parallel via Promise.allSettled
// so that a failure or timeout on one model never blocks the others. Pairs
// marked "only use if needed" are held back and only called if none of the
// "always" pairs came back usable. Each model is expected to return
// {prediction, research_probability, review_probability}; the probabilities
// from every model that answered successfully are averaged to produce the
// final result.

// Reads the configured (key, model, onlyIfNeeded) tuples from storage.
// Supports the new `openrouterConfigs` array (up to 5 entries) and falls
// back to the legacy single `openrouterKey` / `openrouterModel` fields so
// existing installs keep working without any migration step.
async function getConfiguredPairs() {
  const stored = await chrome.storage.local.get([
    'openrouterConfigs',
    'openrouterKey',
    'openrouterModel',
  ]);

  let configs = Array.isArray(stored.openrouterConfigs) ? stored.openrouterConfigs : [];
  configs = configs
    .filter((c) => c && typeof c.key === 'string' && typeof c.model === 'string')
    .map((c) => ({ key: c.key.trim(), model: c.model.trim(), onlyIfNeeded: Boolean(c.onlyIfNeeded) }))
    .filter((c) => c.key && c.model)
    .slice(0, 5);

  if (configs.length === 0 && stored.openrouterKey && stored.openrouterModel) {
    configs = [{ key: stored.openrouterKey, model: stored.openrouterModel, onlyIfNeeded: false }];
  }

  return configs;
}

// Shared OpenRouter call used by both classification paths above. Returns
// null (rather than throwing) whenever the AI genuinely isn't available —
// no key/model configured at all, or every configured model failed/timed
// out/returned something unparseable — so callers can fall back to the
// heuristic in one place.
//
// Each configured pair can be marked "only use if needed" on the settings
// page. Those are held back and only called if every regular ("always")
// pair failed/timed out/errored — so a cheap or rate-limited backup key
// isn't spending a request on every single paper, only on the ones the
// primary model(s) couldn't handle.
async function callOpenRouterClassifier(prompt) {
  const pairs = await getConfiguredPairs();
  if (pairs.length === 0) return null;

  const always = pairs.filter((p) => !p.onlyIfNeeded);
  const fallback = pairs.filter((p) => p.onlyIfNeeded);

  let successes = await runPairs(always, prompt);

  if (successes.length === 0 && fallback.length > 0) {
    successes = await runPairs(fallback, prompt);
  }

  if (successes.length === 0) return null;

  return ensemble(successes);
}

// Runs a group of (key, model) pairs in parallel via Promise.allSettled and
// returns only the ones that produced a usable result.
async function runPairs(pairs, prompt) {
  if (pairs.length === 0) return [];

  const settled = await Promise.allSettled(
    pairs.map((pair) => callSingleModel(pair.key, pair.model, prompt))
  );

  return settled.filter((s) => s.status === 'fulfilled' && s.value).map((s) => s.value);
}

// Calls a single OpenRouter (key, model) pair with the given prompt and
// parses its response. Returns null if the model's output can't be used
// (bad HTTP status or unparseable JSON) so the caller can drop it from the
// ensemble; network errors/timeouts reject instead, which Promise.allSettled
// also treats as a per-model failure without affecting the others.
async function callSingleModel(key, model, prompt) {
  const res = await fetchWithTimeout(
    'https://openrouter.ai/api/v1/chat/completions',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${key}`,
      },
      body: JSON.stringify({
        model,
        messages: [{ role: 'user', content: prompt }],
        temperature: 0,
      }),
    },
    LLM_TIMEOUT_MS
  );

  if (!res.ok) return null;

  const data = await res.json();
  const text = data?.choices?.[0]?.message?.content || '';
  const parsed = parseModelOutput(text);
  return parsed ? { model, ...parsed } : null;
}

// Averages the probabilities from every model that answered successfully
// and derives the final prediction/confidence from that average. On top of
// the { type, confidence } shape the rest of the extension already expects,
// this now also returns:
//   - reason:  a one-line summary of how the models agreed/disagreed
//   - details: each model's own prediction, probabilities, and reason, so
//              the UI can show "why" on demand without changing what's
//              displayed by default.
function ensemble(results) {
  const avgResearch = results.reduce((sum, r) => sum + r.research_probability, 0) / results.length;
  const avgReview = results.reduce((sum, r) => sum + r.review_probability, 0) / results.length;

  const type = avgResearch >= avgReview ? 'Research' : 'Review';
  const confidence = Math.round(Math.max(avgResearch, avgReview) * 100);

  const agreeing = results.filter((r) => r.prediction === type).length;
  const reason =
    results.length === 1
      ? results[0].reason || `Classified as ${type}.`
      : `${agreeing} of ${results.length} model${results.length > 1 ? 's' : ''} classified this as ${type}, averaging ${confidence}% confidence.`;

  const details = results.map((r) => ({
    model: r.model,
    prediction: r.prediction,
    research_probability: r.research_probability,
    review_probability: r.review_probability,
    reason: r.reason || '',
  }));

  return { type, confidence, reason, details };
}

function parseModelOutput(text) {
  try {
    const match = text.match(/\{[\s\S]*\}/);
    if (!match) return null;
    const parsed = JSON.parse(match[0]);

    let researchProb = Number(parsed.research_probability);
    let reviewProb = Number(parsed.review_probability);
    if (!Number.isFinite(researchProb) || !Number.isFinite(reviewProb)) return null;

    // Normalize in case a model's pair doesn't sum to exactly 1.
    const sum = researchProb + reviewProb;
    if (sum <= 0) return null;
    researchProb /= sum;
    reviewProb /= sum;

    const prediction = /review/i.test(String(parsed.prediction)) ? 'Review' : 'Research';
    const reason = typeof parsed.reason === 'string' ? parsed.reason.trim().slice(0, 300) : '';
    return { prediction, research_probability: researchProb, review_probability: reviewProb, reason };
  } catch {
    return null;
  }
}
