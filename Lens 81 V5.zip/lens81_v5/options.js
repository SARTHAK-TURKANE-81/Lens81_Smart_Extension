// options.js
// Renders up to 5 "API key + model" rows, backed by chrome.storage.local
// under a single `openrouterConfigs` array: [{ key, model, onlyIfNeeded }, ...].
// A row checked "only use if needed" is held back by the background worker
// and only called if none of the regular rows produced a usable result —
// useful for a backup/cheaper key you don't want spending a request on
// every single paper.
//
// Backward compatibility: installs from before multi-model support stored a
// single pair under `openrouterKey` / `openrouterModel`. On load, if no
// `openrouterConfigs` exists yet, that legacy pair is migrated into row 1
// so existing users keep working without re-entering anything.

const MAX_ROWS = 5;

// Per-provider display strings. Each row can independently pick a provider;
// the key input's placeholder/hint and the model input's placeholder swap
// to match whichever is selected. Model catalogs and slugs change over time
// for every one of these providers, so hints point at the provider's own
// docs/catalog page rather than hardcoding a list here.
const PROVIDER_META = {
  openrouter: {
    label: 'OpenRouter',
    keyPlaceholder: 'sk-or-v1-…',
    modelPlaceholder: '~anthropic/claude-haiku-latest',
    keyHint:
      'Routes to hundreds of models from one key. Create one at ' +
      '<a href="https://openrouter.ai/keys" target="_blank" rel="noopener">openrouter.ai/keys</a>, ' +
      'sent only to openrouter.ai.',
  },
  gemini: {
    label: 'Google Gemini',
    keyPlaceholder: 'AIza…',
    modelPlaceholder: 'gemini-2.5-flash',
    keyHint:
      'Create a key at ' +
      '<a href="https://aistudio.google.com/apikey" target="_blank" rel="noopener">Google AI Studio</a>, ' +
      'sent only to generativelanguage.googleapis.com. Check ' +
      '<a href="https://ai.google.dev/gemini-api/docs/models" target="_blank" rel="noopener">the model list</a> ' +
      'for the current slug.',
  },
  grok: {
    label: 'xAI Grok',
    keyPlaceholder: 'xai-…',
    modelPlaceholder: 'grok-4-fast',
    keyHint:
      'Create a key at ' +
      '<a href="https://console.x.ai" target="_blank" rel="noopener">console.x.ai</a>, sent only to api.x.ai. ' +
      'Check <a href="https://docs.x.ai/docs/models" target="_blank" rel="noopener">the model list</a> ' +
      'for the current slug.',
  },
};

const rowsContainer = document.getElementById('model-rows');
const saveBtn = document.getElementById('save');
const status = document.getElementById('status');
const banner = document.getElementById('banner');
const clearStatus = document.getElementById('clear-status');

let statusGeneration = 0;

function showStatus(kind, message) {
  // kind: 'ok' | 'err' | 'neutral'
  statusGeneration++;
  status.textContent = message;
  status.className = `pill-status ${kind}`;
  status.style.display = 'inline-flex';
}

function hideStatusLater(delay = 2200) {
  // Capture the generation so a stale timer (e.g. from Save) can't hide a
  // newer message shown afterward (e.g. from a row's Test button).
  const generation = statusGeneration;
  setTimeout(() => {
    if (generation === statusGeneration) {
      status.style.display = 'none';
    }
  }, delay);
}

// --- Row rendering -----------------------------------------------------

function buildRow(index) {
  const wrap = document.createElement('div');
  wrap.className = 'model-row';
  wrap.dataset.index = String(index);

  const isFirst = index === 0;
  wrap.innerHTML = `
    <div class="model-row-header">
      <span class="model-row-title">Model ${index + 1}</span>
      <span class="model-row-tag">${isFirst ? 'Required' : 'Optional'}</span>
    </div>
    <div class="field">
      <label>Provider</label>
      <select class="row-provider">
        <option value="openrouter">OpenRouter</option>
        <option value="gemini">Google Gemini</option>
        <option value="grok">xAI Grok</option>
      </select>
    </div>
    <div class="field">
      <label class="row-key-label">API key</label>
      <div class="input-row">
        <input type="password" class="key-input row-key" placeholder="sk-or-v1-…" autocomplete="off" />
        <button type="button" class="toggle-visibility row-toggle-key">Show</button>
      </div>
      <p class="hint row-key-hint" style="margin: 6px 0 0;"></p>
    </div>
    <div class="field">
      <label>Model slug</label>
      <input type="text" class="row-model" placeholder="~anthropic/claude-haiku-latest" autocomplete="off" />
    </div>
    <label class="row-fallback">
      <input type="checkbox" class="row-only-if-needed" />
      <span>Only use this key if the others fail <em>(saves API cost — held back unless it's needed)</em></span>
    </label>
    <div class="row-actions">
      <button type="button" class="row-test">Test</button>
      <span class="row-status pill-status neutral" style="display:none;"></span>
    </div>
  `;
  return wrap;
}

function renderRows() {
  rowsContainer.innerHTML = '';
  for (let i = 0; i < MAX_ROWS; i++) {
    rowsContainer.appendChild(buildRow(i));
  }
  wireRowEvents();
}

function applyProviderUI(row, provider) {
  const meta = PROVIDER_META[provider] || PROVIDER_META.openrouter;
  const keyInput = row.querySelector('.row-key');
  const modelInput = row.querySelector('.row-model');
  const keyHint = row.querySelector('.row-key-hint');
  const keyLabel = row.querySelector('.row-key-label');

  keyLabel.textContent = `${meta.label} API key`;
  keyInput.placeholder = meta.keyPlaceholder;
  modelInput.placeholder = meta.modelPlaceholder;
  keyHint.innerHTML = meta.keyHint;
}

function wireRowEvents() {
  rowsContainer.querySelectorAll('.model-row').forEach((row) => {
    const keyInput = row.querySelector('.row-key');
    const toggleBtn = row.querySelector('.row-toggle-key');
    const testBtn = row.querySelector('.row-test');
    const rowStatus = row.querySelector('.row-status');
    const modelInput = row.querySelector('.row-model');
    const providerSelect = row.querySelector('.row-provider');

    applyProviderUI(row, providerSelect.value);
    providerSelect.addEventListener('change', () => {
      applyProviderUI(row, providerSelect.value);
      // A model slug from one provider is meaningless to another — clear it
      // so nobody accidentally tries to send an OpenRouter slug to Gemini.
      modelInput.value = '';
      setRowStatus(rowStatus, 'neutral', '');
      rowStatus.style.display = 'none';
    });

    toggleBtn.addEventListener('click', () => {
      const hidden = keyInput.type === 'password';
      keyInput.type = hidden ? 'text' : 'password';
      toggleBtn.textContent = hidden ? 'Hide' : 'Show';
    });

    testBtn.addEventListener('click', () => {
      const provider = providerSelect.value;
      const key = keyInput.value.trim();
      const model = modelInput.value.trim();

      if (!key || !model) {
        setRowStatus(rowStatus, 'err', 'Add a key and model first.');
        return;
      }

      setRowStatus(rowStatus, 'neutral', 'Testing…');
      testBtn.disabled = true;

      chrome.runtime.sendMessage({ type: 'TEST_KEY', provider, key, model }, (response) => {
        testBtn.disabled = false;
        if (chrome.runtime.lastError || !response) {
          setRowStatus(rowStatus, 'err', 'Could not reach the background worker.');
          return;
        }
        setRowStatus(rowStatus, response.ok ? 'ok' : 'err', response.message);
      });
    });
  });
}

function setRowStatus(el, kind, message) {
  el.textContent = message;
  el.className = `row-status pill-status ${kind}`;
  el.style.display = 'inline-flex';
}

function getRows() {
  return Array.from(rowsContainer.querySelectorAll('.model-row'));
}

function readRowValues() {
  return getRows().map((row) => ({
    provider: row.querySelector('.row-provider').value || 'openrouter',
    key: row.querySelector('.row-key').value.trim(),
    model: row.querySelector('.row-model').value.trim(),
    onlyIfNeeded: row.querySelector('.row-only-if-needed').checked,
  }));
}

function writeRowValues(configs) {
  getRows().forEach((row, i) => {
    // Entries saved before multi-provider support have no `provider` field
    // at all — they were always OpenRouter, so default to that rather than
    // leaving the row on whatever the <select> happens to default to.
    const entry = configs[i] || { provider: 'openrouter', key: '', model: '', onlyIfNeeded: false };
    const providerSelect = row.querySelector('.row-provider');
    providerSelect.value = PROVIDER_META[entry.provider] ? entry.provider : 'openrouter';
    applyProviderUI(row, providerSelect.value);
    row.querySelector('.row-key').value = entry.key || '';
    row.querySelector('.row-model').value = entry.model || '';
    row.querySelector('.row-only-if-needed').checked = Boolean(entry.onlyIfNeeded);
  });
}

// --- Load / migrate / save ------------------------------------------------

async function refreshBanner(configs) {
  const anyConfigured = configs.some((c) => c.key && c.model);
  banner.classList.toggle('show', !anyConfigured);
}

async function load() {
  renderRows();

  const stored = await chrome.storage.local.get([
    'openrouterConfigs',
    'openrouterKey',
    'openrouterModel',
  ]);

  let configs = Array.isArray(stored.openrouterConfigs) ? stored.openrouterConfigs : null;

  if (!configs) {
    // Legacy single key/model install — migrate into row 1 on the fly.
    configs = [];
    if (stored.openrouterKey && stored.openrouterModel) {
      configs.push({ provider: 'openrouter', key: stored.openrouterKey, model: stored.openrouterModel });
    }
  }

  writeRowValues(configs);
  await refreshBanner(configs);
}

saveBtn.addEventListener('click', async () => {
  const configs = readRowValues();
  await chrome.storage.local.set({ openrouterConfigs: configs });
  // Once this page has been saved once, openrouterConfigs is the source of
  // truth going forward, so the old single-pair fields can be cleared.
  // (The background worker still reads them as a fallback for any install
  // that hasn't opened this settings page since the update.)
  await chrome.storage.local.remove(['openrouterKey', 'openrouterModel']);

  showStatus('ok', 'Saved.');
  hideStatusLater();
  await refreshBanner(configs);
});

document.getElementById('clear-cache').addEventListener('click', async () => {
  const all = await chrome.storage.local.get(null);
  const cacheKeys = Object.keys(all).filter((k) => k.startsWith('classify:'));
  await chrome.storage.local.remove(cacheKeys);
  clearStatus.textContent = `Cleared ${cacheKeys.length} cached result(s).`;
  setTimeout(() => (clearStatus.textContent = ''), 2500);
});

document.getElementById('back').addEventListener('click', () => {
  // Options pages usually open in their own tab with nothing before them in
  // history, so fall back to closing the tab when there's nowhere to go back to.
  if (window.history.length > 1) {
    window.history.back();
  } else {
    window.close();
  }
});

load();
