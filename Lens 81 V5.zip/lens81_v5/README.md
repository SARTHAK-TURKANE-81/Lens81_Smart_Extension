# Lens⁸¹

Labels each Google Scholar result as **Research** or **Review** by looking up
its abstract (Semantic Scholar, falling back to OpenAlex) and classifying it
with an ensemble of up to 5 LLMs you access through your own API keys —
OpenRouter, Google Gemini, or xAI Grok, mixed and matched per row.

## Load it in Chrome

1. Go to `chrome://extensions`.
2. Turn on **Developer mode** (top right).
3. Click **Load unpacked** and select this folder.
4. Click the extension icon → **Open settings**.

## Configure your model rows

The settings page has 5 rows — Model 1 is required, Models 2–5 are
optional. Fill in as many as you want (1 is enough for the extension to
work; more rows means the ensemble averages more models' predictions).

Each row independently picks a **provider**:

| Provider | Key from | Sent to | Model slug example |
|---|---|---|---|
| OpenRouter | [openrouter.ai/keys](https://openrouter.ai/keys) | `openrouter.ai` | `anthropic/claude-haiku-4.5` |
| Google Gemini | [Google AI Studio](https://aistudio.google.com/apikey) | `generativelanguage.googleapis.com` | `gemini-2.5-flash` |
| xAI Grok | [console.x.ai](https://console.x.ai) | `api.x.ai` | `grok-4-fast` |

Model catalogs and slugs change over time for every one of these
providers, so check the provider's own model list rather than trusting a
hardcoded default — the extension intentionally ships with these fields
blank, and switching a row's provider clears its model field so you don't
accidentally send one provider's slug to another.

For each row you use:

1. Pick a **provider** from the dropdown.
2. Paste in that provider's **API key**. Keys are stored only in your
   browser (`chrome.storage.local`) and are sent only to that provider's own
   API host — never bundled into the extension or sent anywhere else, and
   never sent to any provider other than the one selected for that row.
3. Paste in a **model slug** from that provider's current model catalog
   (see table above).
4. Click that row's **Test** button — this sends one tiny real request
   to that provider so a bad key or mistyped model slug shows up
   immediately instead of failing silently later on a Scholar page.
5. Optionally, check **"Only use this key if the others fail"** on a row.
   That key is held back and only called when every regular row failed or
   timed out on a given paper — handy for a backup or free-tier key you
   don't want spending a request on every single paper, only on the ones
   your main model(s) couldn't handle. This works across providers too —
   e.g. a Gemini row as the "always" model and an OpenRouter row held back
   as backup.

When you're done, click **Save** once at the bottom to store all the rows.

**OpenRouter-specific tip:** avoid `:free` models (they cap out around 20
requests/minute) and models with mandatory reasoning (slower, no accuracy
benefit for this task); `~anthropic/claude-haiku-latest` is a solid,
self-updating default.

## Use it

Open a search results page on `scholar.google.com`. Each result gets a small
chip — cyan for Research, amber for Review — next to the title once its
abstract has been classified. The toolbar icon shows a running count for the
current tab, and clicking it opens a popup with a Research/Review breakdown.
Results are cached locally for 30 days per title, so revisiting a search
won't re-spend API calls.

If no key/model is set, or no abstract can be found for a paper, the
extension falls back to a title-keyword heuristic (looking for words like
"survey," "review," "systematic review," "meta-analysis") and marks the badge
as lower-confidence — hover it to see the note.

## How it works

```
Google Scholar page
   │  content.js scans .gs_ri result blocks, extracts each title
   ▼
background.js (service worker)
   │  checks chrome.storage.local cache
   │  fetches abstract: Semantic Scholar → OpenAlex fallback
   │  (OpenAlex returns an inverted-index, which is reconstructed to text)
   │  verifies the returned title actually matches before trusting it
   ▼
The exact same prompt is sent to every configured (provider, key, model)
row in parallel (Promise.allSettled) — 1 to 5 models, any mix of
OpenRouter/Gemini/Grok
   │  each is prompted to return
   │  {"prediction": "...", "research_probability": 0-1, "review_probability": 0-1}
   │  as JSON
   ▼
Ensemble: research_probability and review_probability are averaged across
every model that answered successfully; whichever average is higher wins
   ▼
Badge injected next to the title on the page, result cached
```

## Performance & reliability

Three specific fixes worth knowing about, since they weren't there originally:

- **Instant guess, then confirmation.** Each result gets a dashed, "…?"
  badge immediately from a title keyword check (0ms), then it's swapped for
  the confirmed abstract-based badge when that arrives. You're never staring
  at a blank spinner.
- **Every network call has a timeout** (6s for abstract lookups, 12s for the
  LLM call). Before this, a single stalled request could leave a badge stuck
  forever with no fallback — now it always resolves to something.
- **Per-tab counts survive the service worker being unloaded.** Chrome can
  suspend an extension's background worker whenever it's been idle for a bit
  — including simply because you switched away from the tab. The running
  Research/Review counts are now kept in `chrome.storage.session` instead of
  a plain variable, so they don't reset just because the tab wasn't focused.
  This needs Chrome 102+; anything from the last few years is fine.
- Semantic Scholar and OpenAlex are now queried **in parallel** instead of
  one-after-the-other, which roughly halves the wait on papers Semantic
  Scholar doesn't have (a common case).

## Collections

A lightweight, local-only way to organize papers into project buckets —
think Spotify/YouTube playlists, not a reference manager. No accounts, no
sync, no cloud, no citations, no PDFs.

- On any Scholar result, once the badge is confirmed you'll see a small
  **➕ Save** control next to it. Click it to open a small "Save to
  Collection" checklist — check/uncheck collections and it saves instantly,
  no Save button needed. **+ New Collection** creates one (duplicate names
  are rejected) and immediately saves the current paper into it.
- A paper can belong to any number of collections at once. Removing it from
  one doesn't touch the others.
- Once saved anywhere, the control becomes **✔ Saved** and a folder chip
  (e.g. `📁 Thesis • Read Later`) appears beside it — including the next
  time you load the same search, so already-organized papers are obvious
  at a glance.
- The toolbar popup has a **Collections** section listing every collection
  with its paper count, a **+ New Collection** shortcut, and **⬇ Export
  All**. Clicking a collection opens a full page (`collection.html`) listing
  its papers (with Open / Remove buttons), plus rename, delete, and
  **⬇ Export Collection**.
- Export supports **CSV**, **Excel (.xlsx)**, **JSON**, **BibTeX (.bib)**,
  and **Markdown**, entirely from local data — no network call involved.
  - CSV/Excel: one row per paper — Collection(s), Title, Authors,
    Classification, Confidence, Google Scholar URL, Date Saved.
  - JSON: the same fields per paper, with Collection(s) expanded into a
    real array instead of a semicolon-joined string, for scripting or
    importing elsewhere.
  - BibTeX: one `@misc` entry per paper, for pulling straight into a
    reference manager. Deliberately has no `year` field — Lens⁸¹ never
    scrapes a publication year, only the date a paper was *saved*, and a
    wrong year in a citation is worse than a missing one. The save date
    and classification are recorded in `note` instead, and the Scholar
    link in `howpublished`.
  - Markdown: a readable reading list (heading + link per paper), meant for
    dropping into Notion/Obsidian/a plain note rather than a spreadsheet.

**Storage:** collections and papers are both kept in `chrome.storage.local`,
separate from the classification cache. Paper metadata is stored exactly
once per paper (keyed by a stable id — a Google Scholar cluster id when the
result URL has one, otherwise a normalized title); collections only ever
reference paper ids, the same way a playlist references songs. Deleting a
collection never deletes a paper that's saved anywhere else; a paper's
storage record is only removed once it belongs to zero collections. See the
comments at the top of `collections.js` for the exact key shapes.

**New files added for this feature:**

| File | Role |
|---|---|
| `collections.js` | Shared storage/CRUD/export logic — loaded by the content script and both extension pages |
| `collections-content.js` | In-page UI: the Save control, the inline "Save to Collection" popover, the New Collection form, the saved-folder chip |
| `collection.html` / `collection.js` | Full-page single-collection view: list, rename, delete, per-collection export |
| `mini-xlsx.js` | Dependency-free `.xlsx` writer (see comments in the file for why it's hand-rolled instead of a vendored library) |

Nothing about the existing classification pipeline, caching, settings, or
ensemble logic was changed to add this — it's wired in at two small points
(one call in `content.js` after a badge is confirmed, one new section in
`popup.html`/`popup.js`).

## Known limitations

- **Cached results don't know your config changed.** Classifications are
  cached for 30 days per title, keyed only by the title text. If a paper
  was classified before you added or changed models (including switching
  providers on a row), revisiting it will keep showing that older cached
  result (including a keyword-only guess from before you had any model
  configured) until the cache entry expires. Use **Clear cache** on the
  settings page after changing your model setup to force reclassification.
- **A model that's silently failing looks different from "not configured"
  now, on purpose.** If some or all of your configured models fail for a
  given paper (commonly: a `:free`-tier OpenRouter model getting
  rate-limited around 20 req/min, a mistyped model slug, or a transient
  provider error/outage on any of the three), the badge and "why" panel
  say so explicitly and list which model(s) failed and why — rather than
  the older behavior of silently falling back and reporting "no AI model
  is configured" even when one was. If you're only ever seeing one model
  respond in the "why" panel despite configuring more, click the badge —
  the others should now show up there as failed attempts with a reason
  (rate limit, timeout, bad response), which is the actual diagnostic to
  act on (e.g. swap out a `:free` model, fix a model slug, or re-`Test`
  the row in Settings).

- **Icons were missing from the original upload.** `manifest.json` and the
  HTML pages reference `icons/icon16.png` / `32` / `48` / `128`, but no
  `icons/` folder existed — Chrome refuses to load an unpacked extension
  with a missing manifest icon, so this was launch-blocking. A simple
  placeholder icon set (the cyan Lens⁸¹ brand color, a lens glyph) has been
  added at those exact paths/sizes; swap them out for real artwork whenever
  you have it.

- **Selectors are fragile.** Google Scholar's markup (`.gs_ri`, `h3`) can
  change; if badges stop appearing, that's the first place to check.
- **Chrome only for now** (Manifest V3, `service_worker` background). A
  Firefox build needs a separate manifest since Firefox's MV3 background
  model differs — happy to add this next if you want it.
- **Not every paper is indexed** in Semantic Scholar or OpenAlex, and some
  publishers withhold abstracts from these APIs, so the heuristic fallback
  will trigger for a portion of results.
- **Title matching is approximate.** A crude similarity check filters out
  obviously wrong matches, but very generic titles could still occasionally
  pull the wrong paper's abstract.

## Files

| File | Role |
|---|---|
| `manifest.json` | Extension config (MV3) |
| `content.js` | Scans the Scholar page, injects badges |
| `background.js` | Abstract lookup, caching, OpenRouter/Gemini/Grok calls, ensemble |
| `options.html` / `options.js` | Where you set up to 5 provider + key + model rows |
| `popup.html` / `popup.js` | Toolbar popup, shows setup status |
| `styles.css` | Badge appearance |
