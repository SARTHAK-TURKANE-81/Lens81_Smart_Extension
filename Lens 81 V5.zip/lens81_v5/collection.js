// collection.js
// Behavior for the standalone collection-view page (collection.html),
// opened from the popup's collection list. Uses collections.js for all
// storage access — see that file for the storage shape.

const params = new URLSearchParams(location.search);
const collectionId = params.get('id');

const titleEl = document.getElementById('title');
const renameInput = document.getElementById('rename-input');
const renameBtn = document.getElementById('rename-btn');
const deleteBtn = document.getElementById('delete-btn');
const confirmBar = document.getElementById('confirm-bar');
const countNote = document.getElementById('count-note');
const paperListEl = document.getElementById('paper-list');
const exportBtn = document.getElementById('export-btn');
const exportMenu = document.getElementById('export-menu');

const renameErr = document.getElementById('rename-err');

let renaming = false;

function paperTypeClass(type) {
  if (type === 'Research') return 'research';
  if (type === 'Review') return 'review';
  return 'unknown';
}

function paperTypeLabel(type) {
  if (type === 'Research') return '📘 Research';
  if (type === 'Review') return '📙 Review';
  return '— Unclassified';
}

async function loadCollectionOrBail() {
  const collections = await lens81GetAllCollections();
  const coll = collections[collectionId];
  if (!coll) {
    titleEl.textContent = 'Collection not found';
    countNote.textContent = 'It may have been deleted already.';
    return null;
  }
  return coll;
}

async function render() {
  const coll = await loadCollectionOrBail();
  if (!coll) return;

  titleEl.textContent = `📁 ${coll.name}`;
  document.title = `Lens⁸¹ — ${coll.name}`;
  countNote.textContent = `${coll.paperIds.length} paper${coll.paperIds.length === 1 ? '' : 's'}`;

  const papers = await lens81GetPapers(coll.paperIds);
  const ordered = coll.paperIds.map((id) => papers[id]).filter(Boolean);
  ordered.sort((a, b) => (b.savedAt || 0) - (a.savedAt || 0));

  paperListEl.innerHTML = '';

  if (ordered.length === 0) {
    const empty = document.createElement('div');
    empty.className = 'empty-state';
    empty.textContent = 'No papers saved here yet. Save one from a Google Scholar search page.';
    paperListEl.appendChild(empty);
    return;
  }

  ordered.forEach((paper) => {
    const row = document.createElement('div');
    row.className = 'paper-row';

    const badge = document.createElement('span');
    badge.className = `paper-badge ${paperTypeClass(paper.type)}`;
    badge.textContent =
      paper.type && Number.isFinite(paper.confidence)
        ? `${paperTypeLabel(paper.type)} · ${paper.confidence}%`
        : paperTypeLabel(paper.type);
    row.appendChild(badge);

    const main = document.createElement('div');
    main.className = 'paper-main';

    const link = document.createElement('a');
    link.className = 'paper-title';
    link.href = paper.url || '#';
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    link.textContent = paper.title || '(untitled)';
    main.appendChild(link);

    if (paper.authors) {
      const meta = document.createElement('div');
      meta.className = 'paper-meta';
      meta.textContent = paper.authors;
      main.appendChild(meta);
    }

    row.appendChild(main);

    const actions = document.createElement('div');
    actions.className = 'paper-actions';

    const openBtn = document.createElement('button');
    openBtn.type = 'button';
    openBtn.className = 'btn-open';
    openBtn.textContent = 'Open';
    openBtn.addEventListener('click', () => window.open(paper.url || '#', '_blank', 'noopener'));

    const removeBtn = document.createElement('button');
    removeBtn.type = 'button';
    removeBtn.className = 'btn-remove';
    removeBtn.textContent = 'Remove';
    removeBtn.addEventListener('click', async () => {
      removeBtn.disabled = true;
      await lens81RemovePaperFromCollection(paper.id, collectionId);
      render();
    });

    actions.appendChild(openBtn);
    actions.appendChild(removeBtn);
    row.appendChild(actions);

    paperListEl.appendChild(row);
  });
}

// --- Rename -----------------------------------------------------------

renameBtn.addEventListener('click', async () => {
  if (!renaming) {
    renaming = true;
    renameErr.style.display = 'none';
    renameInput.value = titleEl.textContent.replace(/^📁\s*/, '');
    titleEl.style.display = 'none';
    renameInput.style.display = 'block';
    renameInput.focus();
    renameInput.select();
    return;
  }
  await commitRename();
});

renameInput.addEventListener('keydown', async (e) => {
  if (e.key === 'Enter') await commitRename();
  if (e.key === 'Escape') {
    renaming = false;
    renameErr.style.display = 'none';
    titleEl.style.display = 'block';
    renameInput.style.display = 'none';
  }
});

async function commitRename() {
  const name = renameInput.value.trim();
  if (!name) {
    renameErr.textContent = 'Enter a name.';
    renameErr.style.display = 'block';
    return;
  }
  const res = await lens81RenameCollection(collectionId, name);
  if (res.error === 'duplicate') {
    renameErr.textContent = 'A collection with that name already exists.';
    renameErr.style.display = 'block';
    return; // stay in edit mode so the user can pick another name
  }
  if (res.error) {
    renameErr.textContent = 'Could not rename the collection.';
    renameErr.style.display = 'block';
    return;
  }
  renaming = false;
  renameErr.style.display = 'none';
  titleEl.style.display = 'block';
  renameInput.style.display = 'none';
  await render();
}

// --- Delete -------------------------------------------------------------

deleteBtn.addEventListener('click', () => confirmBar.classList.add('show'));
document.getElementById('cancel-delete').addEventListener('click', () => confirmBar.classList.remove('show'));
document.getElementById('confirm-delete').addEventListener('click', async () => {
  await lens81DeleteCollection(collectionId);
  closeThisTab();
});

// Reliably closes the tab this page is running in, regardless of whether it
// was opened via window.open() or chrome.tabs.create() (the latter is how
// the popup opens this page — window.close() alone isn't guaranteed to work
// for tabs a script didn't open itself, but an extension can always close
// its own tab by id).
function closeThisTab() {
  if (chrome.tabs && chrome.tabs.getCurrent) {
    chrome.tabs.getCurrent((tab) => {
      if (tab && tab.id != null) {
        chrome.tabs.remove(tab.id);
      } else {
        window.close();
      }
    });
  } else {
    window.close();
  }
}

// --- Export ---------------------------------------------------------------

exportBtn.addEventListener('click', (e) => {
  e.stopPropagation();
  exportMenu.style.display = exportMenu.style.display === 'block' ? 'none' : 'block';
});
exportMenu.querySelectorAll('button[data-format]').forEach((btn) => {
  btn.addEventListener('click', async () => {
    exportMenu.style.display = 'none';
    const count = await lens81ExportCollection(collectionId, btn.dataset.format);
    flashExportFeedback(count);
  });
});
document.addEventListener('click', () => {
  exportMenu.style.display = 'none';
});

function flashExportFeedback(count) {
  const original = exportBtn.textContent;
  exportBtn.textContent = count > 0 ? `✓ Exported ${count}` : 'Nothing to export yet';
  exportBtn.disabled = true;
  setTimeout(() => {
    exportBtn.textContent = original;
    exportBtn.disabled = false;
  }, 1800);
}

document.getElementById('back').addEventListener('click', () => {
  if (window.history.length > 1) window.history.back();
  else window.close();
});

if (!collectionId) {
  titleEl.textContent = 'No collection specified';
  countNote.textContent = '';
  // Without a real collectionId, lens81ExportCollection(null, …) would
  // export *every* collection instead of doing nothing — surprising and
  // wrong on a page that just said there's no collection here. Disable the
  // button outright rather than let that happen.
  exportBtn.disabled = true;
  exportBtn.title = 'No collection to export.';
} else {
  render();
}
