// background.js (MV3 service worker)
// Handles messages from content.js: looks up an abstract, classifies it,
// caches the result, and returns it.
//
// Two reliability rules this file follows, because a service worker can be
// suspended by Chrome at any time (e.g. when its tab isn't focused):
//   1. Every network call has a timeout, so one stalled request can't leave
//      a badge stuck on "checking…" forever.
//   2. Per-tab counters live in chrome.storage.session, not a plain JS
//      variable, so they survive the worker being unloaded and restarted.

const CACHE_TTL_MS = 30 * 24 * 60 * 60 * 1000; // 30 days
const REVIEW_KEYWORDS = /\b(survey|review|systematic review|meta-analysis|overview of)\b/i;

const ABSTRACT_TIMEOUT_MS = 6000;
const LLM_TIMEOUT_MS = 12000;
const TEST_TIMEOUT_MS = 8000;

chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.status === 'loading') {
    chrome.storage.session.remove(tabStatsKey(tabId)).catch(() => {});
    chrome.action.setBadgeText({ tabId, text: '' });
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === 'CLASSIFY_PAPER') {
    classifyPaper(message.title)
      .then(async (result) => {
        if (sender.tab?.id != null) await recordStat(sender.tab.id, result);
        sendResponse(result);
      })
      .catch(() => sendResponse({ error: 'unavailable' }));
    return true; // keep the message channel open for the async sendResponse
  }

  if (message?.type === 'GET_TAB_STATUS') {
    getTabStats(message.tabId).then(sendResponse);
    return true;
  }

  if (message?.type === 'TEST_KEY') {
    testKey(message.key, message.model)
      .then(sendResponse)
      .catch((err) => sendResponse({ ok: false, message: String(err) }));
    return true;
  }

  return false;
});

// --- Per-tab stats, persisted so a worker restart doesn't lose them -------

function tabStatsKey(tabId) {
  return `tabstats:${tabId}`;
}

async function getTabStats(tabId) {
  const stored = await chrome.storage.session.get(tabStatsKey(tabId));
  return stored[tabStatsKey(tabId)] || { research: 0, review: 0, total: 0 };
}

async function recordStat(tabId, result) {
  const stats = await getTabStats(tabId);
  if (result.type === 'Review') stats.review += 1;
  else if (result.type === 'Research') stats.research += 1;
  else return; // classification errored out — don't count it
  stats.total += 1;

  await chrome.storage.session.set({ [tabStatsKey(tabId)]: stats });
  chrome.action.setBadgeText({ tabId, text: String(stats.total) });
  chrome.action.setBadgeBackgroundColor({ tabId, color: '#06AED5' });
}

// --- Networking helper -----------------------------------------------------

async function fetchWithTimeout(url, options = {}, timeoutMs = 6000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...options, signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

// --- Classification pipeline ------------------------------------------------

async function classifyPaper(title) {
  const cacheKey = 'classify:' + normalize(title);
  const cached = await getCache(cacheKey);
  if (cached) return cached;

  const abstract = await fetchAbstract(title);
  // If no abstract was found, still ask the AI — using just the title is
  // meaningfully better than a keyword regex — before falling back further.
  const result = abstract ? await classifyWithLLM(title, abstract) : await classifyTitleOnly(title);

  await setCache(cacheKey, result);
  return result;
}

async function testKey(key, model) {
  if (!key || !model) return { ok: false, message: 'Add both a key and a model first.' };

  try {
    const res = await fetchWithTimeout(
      'https://openrouter.ai/api/v1/chat/completions',
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${key}`,
        },
        body: JSON.stringify({
          model,
          messages: [{ role: 'user', content: 'Reply with the single word: ok' }],
          max_tokens: 5,
        }),
      },
      TEST_TIMEOUT_MS
    );

    if (res.ok) return { ok: true, message: 'Connected.' };

    const body = await res.json().catch(() => null);
    const detail = body?.error?.message || `HTTP ${res.status}`;
    return { ok: false, message: detail };
  } catch (err) {
    if (err.name === 'AbortError') {
      return { ok: false, message: 'Timed out — check your connection and try again.' };
    }
    return { ok: false, message: 'Network error — check your connection and try again.' };
  }
}

function normalize(text) {
  return text.trim().toLowerCase().replace(/\s+/g, ' ');
}

async function getCache(key) {
  const stored = await chrome.storage.local.get(key);
  const entry = stored[key];
  if (!entry || Date.now() - entry.savedAt > CACHE_TTL_MS) return null;
  return entry.value;
}

async function setCache(key, value) {
  await chrome.storage.local.set({ [key]: { value, savedAt: Date.now() } });
}

// --- Abstract lookup ------------------------------------------------------

function titleSimilarity(a, b) {
  a = normalize(a);
  b = normalize(b);
  if (!a || !b) return 0;
  if (a === b) return 1;
  const shorter = a.length < b.length ? a : b;
  const longer = a.length < b.length ? b : a;
  if (longer.includes(shorter)) return shorter.length / longer.length;
  const aTokens = new Set(a.split(' '));
  const bTokens = new Set(b.split(' '));
  const overlap = [...aTokens].filter((t) => bTokens.has(t)).length;
  return overlap / Math.max(aTokens.size, bTokens.size);
}

// Semantic Scholar and OpenAlex are queried in parallel — previously this
// waited for Semantic Scholar to finish (or time out) before ever trying
// OpenAlex, which roughly doubled the wait on any paper Semantic Scholar
// doesn't have. Whichever answers first with a usable abstract wins.
async function fetchAbstract(title) {
  const [ss, oa] = await Promise.allSettled([
    fetchFromSemanticScholar(title),
    fetchFromOpenAlex(title),
  ]);
  if (ss.status === 'fulfilled' && ss.value) return ss.value;
  if (oa.status === 'fulfilled' && oa.value) return oa.value;
  return null;
}

async function fetchFromSemanticScholar(title) {
  const url =
    'https://api.semanticscholar.org/graph/v1/paper/search' +
    `?query=${encodeURIComponent(title)}&fields=title,abstract&limit=1`;
  const res = await fetchWithTimeout(url, {}, ABSTRACT_TIMEOUT_MS);
  if (!res.ok) return null;
  const data = await res.json();
  const paper = data?.data?.[0];
  if (!paper?.abstract) return null;
  if (titleSimilarity(title, paper.title) < 0.6) return null;
  return paper.abstract;
}

async function fetchFromOpenAlex(title) {
  const url = `https://api.openalex.org/works?search=${encodeURIComponent(title)}&per-page=1`;
  const res = await fetchWithTimeout(url, {}, ABSTRACT_TIMEOUT_MS);
  if (!res.ok) return null;
  const data = await res.json();
  const work = data?.results?.[0];
  if (!work) return null;
  if (titleSimilarity(title, work.display_name) < 0.6) return null;
  // OpenAlex stores abstracts as a word -> positions map, not plain text.
  return reconstructAbstract(work.abstract_inverted_index);
}

function reconstructAbstract(invertedIndex) {
  if (!invertedIndex) return null;
  const positions = [];
  for (const [word, indices] of Object.entries(invertedIndex)) {
    for (const idx of indices) positions[idx] = word;
  }
  const text = positions.join(' ').trim();
  return text || null;
}

// --- Classification ---------------------------------------------------

function heuristicClassify(title) {
  const isReview = REVIEW_KEYWORDS.test(title);
  return { type: isReview ? 'Review' : 'Research', confidence: 55, source: 'title-heuristic' };
}

async function classifyWithLLM(title, abstract) {
  const parsed = await callOpenRouterClassifier(buildAbstractPrompt(title, abstract));
  return parsed ? { ...parsed, source: 'llm' } : heuristicClassify(title);
}

// Used when no abstract could be found. A title-only guess from an actual
// model is still meaningfully better than a fixed keyword regex, and is
// labeled distinctly in the UI so it isn't confused with an abstract-verified
// result.
async function classifyTitleOnly(title) {
  const parsed = await callOpenRouterClassifier(buildTitleOnlyPrompt(title));
  return parsed ? { ...parsed, source: 'llm-title-only' } : heuristicClassify(title);
}

function buildAbstractPrompt(title, abstract) {
  return `You are an expert at identifying academic paper types.
Classify the paper as exactly one of: "Research Paper" or "Review Paper".

Title: ${title}
Abstract: ${abstract}

Respond with ONLY compact JSON, no other text:
{"type":"Research Paper" or "Review Paper","confidence":0-100}`;
}

function buildTitleOnlyPrompt(title) {
  return `You are an expert at identifying academic paper types.
No abstract is available for this paper. Using only the title and your general knowledge of how research papers versus review papers are typically titled in this field, make your best judgment. Reflect your reduced certainty in the confidence score.

Title: ${title}

Classify as exactly one of: "Research Paper" or "Review Paper".
Respond with ONLY compact JSON, no other text:
{"type":"Research Paper" or "Review Paper","confidence":0-100}`;
}

// Shared OpenRouter call used by both classification paths above. Returns
// null (rather than throwing) whenever the AI genuinely isn't available —
// no key/model configured, request failed, timed out, or returned something
// unparseable — so callers can fall back to the heuristic in one place.
async function callOpenRouterClassifier(prompt) {
  const { openrouterKey, openrouterModel } = await chrome.storage.local.get([
    'openrouterKey',
    'openrouterModel',
  ]);
  if (!openrouterKey || !openrouterModel) return null;

  try {
    const res = await fetchWithTimeout(
      'https://openrouter.ai/api/v1/chat/completions',
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${openrouterKey}`,
        },
        body: JSON.stringify({
          model: openrouterModel,
          messages: [{ role: 'user', content: prompt }],
          temperature: 0,
        }),
      },
      LLM_TIMEOUT_MS
    );

    if (!res.ok) return null;

    const data = await res.json();
    const text = data?.choices?.[0]?.message?.content || '';
    return parseModelOutput(text);
  } catch {
    return null;
  }
}

function parseModelOutput(text) {
  try {
    const match = text.match(/\{[\s\S]*\}/);
    if (!match) return null;
    const parsed = JSON.parse(match[0]);
    const type = /review/i.test(parsed.type) ? 'Review' : 'Research';
    const confidence = Number.isFinite(parsed.confidence) ? Math.round(parsed.confidence) : null;
    return { type, confidence };
  } catch {
    return null;
  }
}
